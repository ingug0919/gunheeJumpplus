using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce = 10f;
    public Transform groundCheck;
    public float groundCheckRadius = 0.2f;
    public LayerMask groundLayer;
    public Animator animator;
    public int maxJumpCount = 2;

    private Rigidbody2D rb;
    private bool isGrounded;
    private int jumpCount = 0;
    private bool wasGroundedLastFrame;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // 좌우 이동
        float moveInput = Input.GetAxisRaw("Horizontal");
        rb.velocity = new Vector2 (moveInput * moveSpeed, rb.velocity.y);
        
        // 좌우 방향 전환
        if (moveInput != 0 )
        {
            transform.localScale = new Vector3(Mathf.Sign(moveInput), 1, 1);
        }

        // 점프 입력
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);

        if (isGrounded && !wasGroundedLastFrame)
        {
            jumpCount = 0;
        }

        if (Input.GetButtonDown("Jump") &&  jumpCount < maxJumpCount)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
            jumpCount++;
        }

        // 점프 낙하 판정
        bool isJumping = rb.velocity.y > 0.1f && !isGrounded;
        bool isFalling = rb.velocity.y < -0.1f && !isGrounded;

        // 애니메이션
        animator.SetFloat("Speed", Mathf.Abs(moveInput));
        animator.SetBool("isJumping", isJumping);
        animator.SetBool("isFalling", isFalling);
        animator.SetInteger("jumpCount",jumpCount);

        wasGroundedLastFrame = isGrounded;
    }
}
